package com.example.project4task2;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;
/**
 * @author
 * Name: Zhenqi Wang
 * Andrew ID: zhenqiw
 *
 * ApiCall class to fetch meal information using TheMealDB API.
 */
public class ApiCall {
    private String mealNeam;
    private final String apiEnd = "https://www.themealdb.com/api/json/v1/1/search.php?s=";
    private int possibleResults;
    private int numsIngredients = 1;
    // Constructor initializes the meal name.
    public ApiCall(String mealName) {
        this.mealNeam = mealName;
    }
    public int getPossibleResults() {
        return possibleResults;
    }
    public int getNumsIngredients() {
        return numsIngredients;
    }
    // Extracts and returns essential meal information from the JSON object.
    public JSONObject getValidInfo(JSONObject originJson) {
        JSONObject validInfo = new JSONObject();
        if (possibleResults == 0) { // if search failed
            validInfo.put("mealName", "Empty");
            validInfo.put("mealCategory", "Empty");
            validInfo.put("mealArea", "Empty");
            validInfo.put("mealInstructions", "Empty");
            validInfo.put("mealPicture", "Empty");
            validInfo.put("mealVideo", "Empty");
            validInfo.put("mealIngredients", "Empty");
        } else {
            validInfo.put("mealName", originJson.get("strMeal"));
            validInfo.put("mealCategory", originJson.get("strCategory"));
            validInfo.put("mealArea", originJson.get("strArea"));
            validInfo.put("mealInstructions", originJson.get("strInstructions"));
            validInfo.put("mealPicture", originJson.get("strMealThumb"));
            validInfo.put("mealVideo", originJson.get("strYoutube"));
            StringBuilder mealIngredients = new StringBuilder();
            numsIngredients = 1;
            while (true) {
                String ingredientKey = "strIngredient" + numsIngredients;
                String measureKey = "strMeasure" + numsIngredients;
                if (!originJson.optString(ingredientKey).isEmpty() && !originJson.optString(ingredientKey).isEmpty()) {
                    String ingredient = originJson.getString(ingredientKey);
                    String measure = originJson.optString(measureKey, "");
                    mealIngredients.append(measure);
                    mealIngredients.append(" ");
                    mealIngredients.append(ingredient);
                    mealIngredients.append("\n");
                    numsIngredients++;
                } else {
                    break;
                }
            }
            validInfo.put("mealIngredients", mealIngredients.toString());
        }

        return validInfo;
    }

    // Calls TheMealDB API to retrieve meal data based on the meal name.
    public JSONObject getMealData(String mealName) throws IOException {
        String apiURL = "https://www.themealdb.com/api/json/v1/1/search.php?s=" + mealName;

        URL url = new URL(apiURL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");

        if (conn.getResponseCode() != 200) {
            possibleResults = 0;
            return null;
        }

        BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
        String output;
        StringBuilder responseStrBuilder = new StringBuilder();

        while ((output = br.readLine()) != null) {
            responseStrBuilder.append(output);
        }

        conn.disconnect();

        JSONObject jsonResponse = new JSONObject(responseStrBuilder.toString());
        if (jsonResponse.optJSONArray("meals") != null)
        {
            JSONArray meals = jsonResponse.getJSONArray("meals");
            possibleResults = meals.length();
            Random random = new Random();
            int randomIndex = random.nextInt(possibleResults);
            // Assuming the API returns an array of meals and we're interested in the first one
            return meals.getJSONObject(randomIndex);
        }
        return null;
    }
}
