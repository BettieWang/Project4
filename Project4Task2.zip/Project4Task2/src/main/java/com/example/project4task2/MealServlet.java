package com.example.project4task2;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.text.SimpleDateFormat;

/**
 * @author
 * Name: Zhenqi Wang
 * Andrew ID: zhenqiw
 * Servlet for handling meal data retrieval and dashboard operations.
 */
@WebServlet(name = "MealServlet", urlPatterns = {"/getMeal","/dashboard"})
public class MealServlet extends HttpServlet {

    // MongoDB connection string including the credentials and path to the database.
    private static final String connectionString = "mongodb://Bettie:bettie2000@ac-sy56oav-shard-00-00.gvamiky.mongodb.net:27017,ac-sy56oav-shard-00-01.gvamiky.mongodb.net:27017,ac-sy56oav-shard-00-02.gvamiky.mongodb.net:27017/myFirstDatabase?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

    // MongoDB client and collection handles.
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    // Variables for search functionality and data analysis.
    private String searchName;
    private static Date lastRecoredTimestamp = null;
    private ApiCall apiCall = null;
    private DataAnalysis dataAnalysis = null;

    // Initializes the servlet and sets up database connection.
    public void init() {
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(ServerApi.builder().version(ServerApiVersion.V1).build())
                .build();
        mongoClient = MongoClients.create(settings);
        database = mongoClient.getDatabase("Project4Database");
        collection = database.getCollection("Project4Task2");
    }

    // Handles GET requests to either fetch meal data or display the dashboard.
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if ("/getMeal".equals(request.getServletPath())) {
            searchName = request.getParameter("mealName");
            if (searchName != null) {
                apiCall = new ApiCall(searchName);
                JSONObject firstMeal = apiCall.getMealData(searchName);
                response.setContentType("application/json");
                OutputStream os = response.getOutputStream();
                JSONObject json = apiCall.getValidInfo(firstMeal);
                os.write(json.toString().getBytes());
                os.flush();
                os.close();
                recordLog(request, json);
            }
        }
        if ("/dashboard".equals(request.getServletPath())) {
            dataAnalysis = new DataAnalysis(collection);
            request.setAttribute("activityData", dataAnalysis.timeAnalysis());
            request.setAttribute("documents", dataAnalysis.getAllData());
            request.setAttribute("modelData", dataAnalysis.modelAnalysis());
            request.setAttribute("categoryCounts", dataAnalysis.categoryAnalysis());
            request.setAttribute("successRate", dataAnalysis.calculateSuccessRate());
            request.setAttribute("documentsByday", dataAnalysis.countDocumentsForTodayAndYesterday());
            RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
            view.forward(request, response);
        }
    }

    // Records log entries into the MongoDB collection.
    private void recordLog(HttpServletRequest request, JSONObject json) {
        String model = request.getHeader("User-Agent");
        Date currentTimestamp = new Date();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.getDefault());
        dateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York")); // Set to local time zone
        String formattedTimestamp = dateFormat.format(currentTimestamp);

        if (shouldRecord(currentTimestamp)) {
            // Create the log document
            Document log = new Document()
                    .append("timestamp", formattedTimestamp)
                    .append("userInput", searchName)
                    .append("possibleResults", apiCall.getPossibleResults())
                    .append("mealArea", json.getString("mealArea"))
                    .append("mealCategory", json.getString("mealCategory"))
                    .append("numsOfIngredients", apiCall.getNumsIngredients() - 1)
                    .append("model", model);

            // Get the collection and insert the log document
            collection.insertOne(log);
            lastRecoredTimestamp = currentTimestamp;
        }

    }

    // Determines whether to record the log based on the timestamp difference.
    private boolean shouldRecord(Date currentTimestamp) {
        if (lastRecoredTimestamp == null){
            return true;
        }
        long timeDiff = currentTimestamp.getTime() - lastRecoredTimestamp.getTime();
        return TimeUnit.MILLISECONDS.toSeconds(timeDiff) > 2;
    }

    // Clean-up method to close the database client connection when the servlet is destroyed.
    public void destroy() {
        // Close the MongoDB client
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
