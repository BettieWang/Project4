package com.example.project4task2;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
/**
 * @author
 * Name: Zhenqi Wang
 * Andrew ID: zhenqiw
 *
 * DataAnalysis class performs various analysis tasks on data from a MongoDB collection.
 */
public class DataAnalysis {
    private MongoCollection collection;

    // Constructor that initializes the MongoDB collection.
    public DataAnalysis(MongoCollection collection) {
        this.collection = collection;
    }
    // Retrieves all documents from the collection and applies some transformations.
    public List<Document> getAllData() {
        // Retrieve the documents
        FindIterable<Document> iterable = collection.find();
        List<Document> transformedDocuments = new ArrayList<>();
        for (Document doc : iterable) {
            Document transformedDoc = new Document(doc);
            String timestamp = doc.getString("timestamp");
            String model = doc.getString("model");

            // Format timestamp
            if (timestamp != null) {
                timestamp = timestamp.replaceAll("T", " ").substring(0, timestamp.indexOf('.'));
                transformedDoc.put("timestamp", timestamp);
            }

            // Simplify model string
            if (model != null) {
                if (model.contains("Mac OS X")) {
                    model = "Intel Mac OS X 10_15_7";
                } else if (model.contains("Android")) {
                    model = "Android UpsideDownCakePrivacySandbox";
                }
                transformedDoc.put("model", model);
            }

            transformedDocuments.add(transformedDoc);
        }
        return transformedDocuments;
    }

    // Analyzes and counts the number of documents for each hour of the day.
    public Map<Integer, Integer> timeAnalysis(){
        Map<Integer, Integer> hourCounts = new HashMap<>();
        for (int i = 1; i <=24; i++) {
            hourCounts.put(i,0);
        }
        // Retrieve all documents
        FindIterable<Document> documents = collection.find();

        for (Document document : documents) {
            // the timestamp is stored as a string in the format "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
            String timestamp = document.getString("timestamp");
            String hourString = timestamp.substring(11, 13);
            int hour = Integer.parseInt(hourString);
            // Increment the count for this hour
            hourCounts.put(hour, hourCounts.getOrDefault(hour, 0) + 1);

        }
        return hourCounts;
    }
    // Analyzes and counts the occurrences of each model type in the documents.
    public Map<String, Integer> modelAnalysis() {
        Map<String, Integer> modelCounts = new HashMap<>();

        FindIterable<Document> iterable = collection.find();
        for (Document doc : iterable) {
            String model = doc.getString("model");
            if (model != null) {
                // Simplify the model string
                if (model.contains("Macintosh")) {
                    model = "Mac OS";
                } else if (model.contains("Android")) {
                    model = "Android";
                }

                // Count the model occurrences
                Integer count = modelCounts.getOrDefault(model, 0);
                modelCounts.put(model, count + 1);
            }
        }
        return modelCounts;
    }

    // Analyzes and counts the occurrences of each meal category, excluding "Empty".
    public Map<String, Integer> categoryAnalysis() {
        // Match stage to filter out documents with "Empty" as the mealCategory
        Bson match = Aggregates.match(Filters.ne("mealCategory", "Empty"));

        Bson group = Aggregates.group("$mealCategory", Accumulators.sum("count", 1));
        Bson sort = Aggregates.sort(Sorts.descending("count"));
        Bson limit = Aggregates.limit(3); // record the top 3

        // Include the match stage in the aggregation pipeline
        List<Document> results = (List<Document>) collection.aggregate(Arrays.asList(match, group, sort, limit)).into(new ArrayList<>());

        Map<String, Integer> categoryCounts = new LinkedHashMap<>();
        for (Document doc : results) {
            categoryCounts.put(doc.getString("_id"), doc.getInteger("count"));
        }
        return categoryCounts;
    }

    // Calculates the success rate based on the number of documents with non-zero possibleResults.
    public double calculateSuccessRate() {
        long totalDocuments = collection.countDocuments();
        if (totalDocuments == 0) {
            return 0.0; // To avoid division by zero
        }
        long successfulDocuments = collection.countDocuments(Filters.ne("possibleResults", 0));
        return (double) successfulDocuments / totalDocuments;
    }

    // Counts the number of documents for today and yesterday based on their timestamps.
    public Map<String, Long> countDocumentsForTodayAndYesterday() {
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDate today = LocalDate.now(zoneId);
        LocalDate yesterday = today.minusDays(1);

        // ISO 8601 format without milliseconds and timezone for comparison
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).withZone(zoneId);

        String startOfToday = today.atStartOfDay(zoneId).format(formatter);
        String startOfTomorrow = today.plusDays(1).atStartOfDay(zoneId).format(formatter);
        String startOfYesterday = yesterday.atStartOfDay(zoneId).format(formatter);

        long documentsToday = collection.countDocuments(Filters.and(
                Filters.gte("timestamp", startOfToday),
                Filters.lt("timestamp", startOfTomorrow)));

        long documentsYesterday = collection.countDocuments(Filters.and(
                Filters.gte("timestamp", startOfYesterday),
                Filters.lt("timestamp", startOfToday)));

        Map<String, Long> documentCounts = new HashMap<>();
        documentCounts.put("today", documentsToday);
        documentCounts.put("yesterday", documentsYesterday);

        return documentCounts;
    }


}

