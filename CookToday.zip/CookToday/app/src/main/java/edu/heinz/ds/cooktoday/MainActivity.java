package edu.heinz.ds.cooktoday;

import android.os.Bundle;
import com.squareup.picasso.Picasso;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author
 * Name: Zhenqi Wang
 * Andrew ID: zhenqiw
 */
public class MainActivity extends AppCompatActivity {

    MainActivity ma = this;
    String searchName;
    ImageView mealPic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final MainActivity activity = this;

        Button submitButton = (Button)findViewById((R.id.submit));

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("MainActivity", "onClick called");
                searchName = ((EditText)findViewById(R.id.searchName)).getText().toString();
                searchName = searchName.replace(" ", "_");
                GetMeal gm = new GetMeal();
                gm.search(searchName, ma, activity);
            }
        });
    }
    public void mealReady(Meal meal) {
        Log.d("MainActivity", "mealReady called");
        ImageView mealPic = (ImageView)findViewById(R.id.mealPic);
        TextView mealName = findViewById(R.id.mealName);
        TextView searchText = (EditText)findViewById(R.id.searchName);
        TextView mealCat = findViewById(R.id.mealCat);
        TextView mealArea = findViewById(R.id.mealArea);
        TextView mealIngre = findViewById(R.id.mealIngre);
        TextView mealInstructions = findViewById(R.id.mealInstructions);
        WebView mealVideo = findViewById(R.id.mealVideo);
        mealVideo.clearCache(true);  // Pass 'true' to delete the disk cache as well
        if (meal != null && !meal.getName().equals("Empty")) {

            if (meal.getPicLink() != null) {
                mealPic.setVisibility(View.VISIBLE);
                Picasso.get().load(meal.getPicLink()).into(mealPic);
            }

            if (meal.getName() != null) {
                mealName.setVisibility(View.VISIBLE);
                mealName.setText("Name: " + meal.getName());
            }

            if (meal.getCategory() != null) {
                mealCat.setVisibility(View.VISIBLE);
                mealCat.setText("Category: " + meal.getCategory());
            }

            if (meal.getArea() != null) {
                mealArea.setVisibility(View.VISIBLE);
                mealArea.setText("Area: " + meal.getArea());
            }

            if (meal.getIngredients() != null) {
                mealIngre.setVisibility(View.VISIBLE);
                mealIngre.setText("Ingredients: \n" + meal.getIngredients());
            }

            if (meal.getInstructions() != null) {
                mealInstructions.setVisibility(View.VISIBLE);
                mealInstructions.setText("Instructions: \n" + meal.getInstructions());
            }

            if (meal.getVideoLink() != null) {
                mealVideo.getSettings().setJavaScriptEnabled(true);
                mealVideo.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                        super.onReceivedError(view, request, error);
                        Log.e("MainActivity", "Web view error: " + error.getDescription());
                    }

                    @Override
                    public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                        super.onReceivedHttpError(view, request, errorResponse);
                        Log.e("MainActivity", "HTTP error response received: " + errorResponse.getStatusCode());
                    }
                });
                mealVideo.loadUrl(meal.getVideoLink());
                mealVideo.setVisibility(View.VISIBLE);
            }

        } else {
            mealName.setVisibility(View.VISIBLE);
            mealName.setText("Sorry, we cannot find \"" + searchName + "\" related meal.");
            mealPic.setVisibility(View.INVISIBLE);
            mealCat.setVisibility(View.INVISIBLE);
            mealArea.setVisibility(View.INVISIBLE);
            mealIngre.setVisibility(View.INVISIBLE);
            mealInstructions.setVisibility(View.INVISIBLE);
            mealVideo.setVisibility(View.INVISIBLE);
        }
        searchText.setText("");

    }
}