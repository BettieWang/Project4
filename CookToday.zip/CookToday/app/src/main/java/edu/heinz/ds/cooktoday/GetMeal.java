package edu.heinz.ds.cooktoday;

import android.app.Activity;
import android.util.Log;

import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

/**
 * @author
 * Name: Zhenqi Wang
 * Andrew ID: zhenqiw
 * Class to handle the process of searching for meal data from an API asynchronously.
 */
public class GetMeal {
    MainActivity activity = null;
    String searchName = null;
    Meal meal = null;

    /**
     * Initiates an asynchronous search for a meal.
     * @param searchName The name of the meal to search for.
     * @param act The current activity context.
     * @param activity The MainActivity instance for callback.
     */
    public void search(String searchName, Activity act, MainActivity activity) {
        Log.d("GetMeal", "search called with: " + searchName);
        this.activity = activity;
        this.searchName = searchName;
        new BackgroundTask(act).execute();
    }

    /**
     * Inner class to handle asynchronous operations on a background thread.
     */
    private class BackgroundTask {
        private Activity act;
        public BackgroundTask(Activity act) {
            this.act = act;
        }
        private void startBackground() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    doInBackground();
                    act.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute() {
            startBackground();
        }

        private void doInBackground() {
            Log.d("GetMeal", "doInBackground started");
            meal = search(searchName);
        }

        public void onPostExecute() {
            Log.d("GetMeal", "onPostExecute called");
            activity.mealReady(meal);
        }

        /**
         * Searches for a meal using the API.
         * @param searchName The name of the meal to search for.
         * @return The Meal object containing the search results.
         */
        private Meal search(String searchName) {
//            String apiUrl = "https://curly-space-halibut-rjvx67q75vv3wq9w-8080.app.github.dev/getMeal?mealName=" + searchName;
//            String apiUrl = "http://10.0.2.2:8080/Project4Task2-1.0-SNAPSHOT/getMeal?mealName=" + searchName;
            String apiUrl = "https://congenial-garbanzo-4x9rvq5qx5pf7jp6-8080.app.github.dev/getMeal?mealName=" + searchName;
            String jsonResponse = makeApiRequest(apiUrl);

            try {
                JSONObject jsonObject = new JSONObject(jsonResponse);

                if (!jsonObject.equals("")) {
                    meal = new Meal();

                    meal.setName(jsonObject.getString("mealName"));
                    meal.setPicLink(jsonObject.getString("mealPicture"));
                    meal.setCategory(jsonObject.getString("mealCategory"));
                    meal.setArea(jsonObject.getString("mealArea"));
                    meal.setInstructions(jsonObject.getString("mealInstructions"));
                    meal.setVideoLink(jsonObject.getString("mealVideo"));
                    meal.setIngredients(jsonObject.getString("mealIngredients"));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return meal;
        }

        /**
         * Makes an HTTP GET request to the specified API URL and returns the response as a string.
         * @param apiUrl The URL of the API to request data from.
         * @return The JSON response as a string.
         */
        private String makeApiRequest(String apiUrl) {

            String response = "";
            try {
                URL url = new URL(apiUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.connect();

                Log.d("GetMeal", "makeApiRequest called");
                int responseCode = conn.getResponseCode();

                if (responseCode != 200) {
                    return response;
                } else {
                    Scanner sc = new Scanner(url.openStream());
                    while (sc.hasNext()) {
                        response += sc.nextLine();
                    }
                    sc.close();
                }

            } catch (IOException e) {
                return response;
            }
            return response;
        }
    }
}